from FunctionFlow import repeat, repeat_until, exitFunctionIf, skipToFunction, sleep, is_paused, pause_sleep, unpause, run_list

x = 0
@repeat(3)
def test_repeat_function():
    global x
    print("This function will be repeated 3 times.")
    x += 1

@repeat_until(lambda: x == 3)
def test_repeat_until_function():
    print("This function will be repeated until x equals 3.")

test_repeat_function()
test_repeat_until_function()